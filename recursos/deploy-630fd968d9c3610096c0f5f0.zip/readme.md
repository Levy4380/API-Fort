#Deploy en: https://kobetlys.netlify.app

#Web App realizada 100% con React.js

##Proyecto personal en el que estoy realizando la pagina de la tienda de una amiga, utilizando React y JSX para hacer una web app.
